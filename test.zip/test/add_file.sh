#!/bin/bash

pathFile=$1
bucket=$2
#gsutil cp [LOCAL_OBJECT_LOCATION] gs://[DESTINATION_BUCKET_NAME]/
gsutil cp pathFile bucket>&error.txt