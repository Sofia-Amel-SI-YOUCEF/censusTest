import sys
print int(sys.argv[1])+int(sys.argv[2])
