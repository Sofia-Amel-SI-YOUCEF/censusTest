#!/usr/bin/env python

# Copyright 2016 Google, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#create bucket for model
import argparse
import datetime
import pprint
import sys

from google.cloud import storage
bucket_name=sys.argv[1]
destination_blob_name=sys.argv[2]
source_file_name=sys.argv[3]
# Make an authenticated API request
storage_client = storage.Client.from_service_account_json(
        'My First Project-1ff55b3d65c1.json')

# The of bucket where object will be uploaded
#bucket_name = 'test1-model1-bucket'

#path in bucket to object to be uploaded
#destination_blob_name = 'prediction_data/census2.json'

#source file of local object being uploaded
#source_file_name = '/Users/kovilapauvaday/Documents/UNI/S9/PISTL/GoogleCloud/census_dataset/prediction_data/census.json'

#get bucket
#bucket = storage_client.get_bucket(bucket_name)
bucket = storage_client.get_bucket(bucket_name)

#upload object to bucket
blob = bucket.blob(destination_blob_name)
blob.upload_from_filename(source_file_name)

print('File {} uploaded to {}.'.format(
        source_file_name,
        destination_blob_name))

